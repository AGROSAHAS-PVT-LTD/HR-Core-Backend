@php
    use App\Models\Settings;
    $title = 'Settings | Super Admin';
    $settings = Settings::first();
@endphp

@extends('layout')

@section('title', $title)

@section('main-content')
   @include('nav')
    <div class="row mb-3 mt-5">
        <div class="col">
            <div class="float-start">
                <h4 class="mt-2">{{$title}}</h4>
            </div>
        </div>
        
    </div>
     <div class="card mb-4">
          <!-- General Error Message -->
            @if (session('error'))
                <div class="alert alert-danger">
                    {{ session('error') }}
                </div>
            @endif
        <div class="card-body">
            <div class="d-flex align-items-start">
                <div class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist" aria-orientation="vertical" style="width:20%">
                    <button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">Super Admin Settings</button>
                   {{-- <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">SMS Settings</button>--}}
                    <button class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-messages" type="button" role="tab" aria-controls="v-pills-messages" aria-selected="false">Portal Dashboard Settings</button>
                    <button class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-settings" type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false">Mobile App Settings</button>
                    <button class="nav-link" id="v-pills-map-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-map-settings" type="button" role="tab" aria-controls="v-pills-map-settings" aria-selected="false">Portal & App Map Settings</button>
                    <button class="nav-link" id="v-pills-payment-modes-tab" data-bs-toggle="pill" data-bs-target="#v-pills-payment-modes" type="button" role="tab" aria-controls="v-pills-payment-modes" aria-selected="false">Payment Gateways</button>
                    
                
                </div>
                <div class="tab-content w-100" id="v-pills-tabContent">
                    <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                        <div class="card">
                            <div class="card-header">
                                <h6>Super Admin Settings</h6>
                            </div>
                            <div class="card-body">
                                <form class="form-horizontal" action="{{route('settings.updateBasicSettings')}}" method="post">
                                    @csrf
                                    <div class="row mb-3">
                                        <label class="col-6 col-form-label">App Name</label>
                                        <div class="col-6">
                                            <input type="text" class="form-control" id="appName" name="appName" placeholder="Application Name" value="{{$settings->app_name}}">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-6 col-form-label">App Version</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" id="appVersion" name="appVersion" placeholder="Application Version" value="{{$settings->app_version}}">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-6 col-form-label">Country Code</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" id="country" name="country" placeholder="Country Code" value="{{$settings->country}}">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-6 col-form-label">Country Phone Code</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" id="phoneCountryCode" name="phoneCountryCode" placeholder="Country Phone Code" value="{{$settings->phone_country_code}}">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-6 col-form-label">Currency</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" id="currency" name="currency" placeholder="Currency" value="{{$settings->currency}}">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-6 col-form-label">Currency Symbol</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" id="currencySymbol" name="currencySymbol" placeholder="Currency Symbol" value="{{$settings->currency_symbol}}">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-6 col-form-label">Distance Unit</label>
                                        <div class="col-sm-6">
                                            <select class="form-control" name="distanceUnit" id="distanceUnit">
                                                <option {{$settings->distance_unit == 'km' ? 'selected' : ''}}>KM</option>
                                                <option {{$settings->distance_unit != 'km' ? 'selected' : ''}}>Miles</option>
                                            </select>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                        <div class="card">
                            <div class="card-header">
                                <h6>Portal Dashboard Settings</h6>
                            </div>
                            <div class="card-body">
                                <form class="form-horizontal" action="{{route('settings.updateDashboardSettings')}}" method="post">
                                    @csrf
                                    <div>
                                        <div class="row mb-3">
                                            <label for="OfflineCheckTimeType" class="col-sm-6 col-form-label">Offline Check Time Type</label>
                                            <div class="col-sm-6">
                                                <select class="form-control" name="offlineCheckTimeType" id="offlineCheckTimeType">
                                                    <option {{$settings->offline_check_time_type == 'seconds' ? 'selected' : ''}}>Seconds</option>
                                                    <option {{$settings->offline_check_time_type != 'seconds' ? 'selected' : ''}}>Minutes</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="inputName" class="col-sm-6 col-form-label">Offline Check Time</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" id="offlineCheckTime" name="offlineCheckTime" placeholder="Offline Check Time" value="{{$settings->offline_check_time}}">
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                        <div class="card">
                            <div class="card-header">
                                <h6>Mobile App Settings</h6>
                            </div>
                            <div class="card-body">
                                <form class="form-horizontal" action="{{route('settings.updateMobileAppSettings')}}" method="post">
                                    @csrf
                                    <div class="col-md-12">
                                        <div class="row mb-3">
                                            <label for="inputName" class="col-sm-6 col-form-label">Mobile App Version</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" id="mobileAppVersion" name="mobileAppVersion" placeholder="Mobile App Version" value="{{$settings->m_app_version}}">
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="inputName" class="col-sm-6 col-form-label">Privacy Policy Link</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" id="privacyPolicyLink" name="privacyPolicyLink" placeholder="Privacy Policy Link" value="{{$settings->privacy_policy_url}}">
                                            </div>
                                        </div>
                                        <hr />
                                        <div class="mb-3">
                                            <span class="text-danger">* Be careful while changing this, less time means more battery consumption in mobile app. Our recommendation is 15 minute</span>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="LocationUpdateIntervalType" class="col-sm-6 col-form-label">Mobile device Update Interval Type </label>
                                            <div class="col-sm-6">
                                                <select class="form-control" id="locationUpdateIntervalType" name="locationUpdateIntervalType">
                                                    <option {{$settings->m_location_update_time_type == 'seconds' ? 'selected' : ''}}">Seconds</option>
                                                    <option {{$settings->m_location_update_time_type != 'seconds' ? 'selected' : ''}}>Minutes</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="inputName" class="col-sm-6 col-form-label">Mobile device Update Interval</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" id="locationUpdateInterval" name="locationUpdateInterval" placeholder="Location Update Interval" value="{{$settings->m_location_update_interval}}">
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="v-pills-map-settings" role="tabpanel" aria-labelledby="v-pills-map-settings-tab">
                        <div class="card">
                            <div class="card-header">
                                <h6>Map Settings</h6>
                            </div>
                            <div class="card-body">
                                <form class="form-horizontal" action="{{route('settings.updateMapSettings')}}" method="post">
                                    @csrf
                                    <div class="col-md-12">
                                        <div class="row mb-3">
                                            <label for="inputName" class="col-sm-6 col-form-label">Latitude</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" id="latitude" name="latitude" placeholder="Latitude" value="{{$settings->center_latitude}}">
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="inputName" class="col-sm-6 col-form-label">Longitude</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" id="longitude" name="longitude" placeholder="Longitude" value="{{$settings->center_longitude}}">
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="inputName" class="col-sm-6 col-form-label">Map Zoom Level</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" id="mapZoomLevel" name="mapZoomLevel" placeholder="Map Zoom Level" value="{{$settings->map_zoom_level}}">
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="v-pills-payment-modes" role="tabpanel" aria-labelledby="v-pills-payment-modes-tab">
                        <div class="card">
                            <div class="card-header">
                                <h6>Payment Mode</h6>
                            </div>
                            <div class="card-body">
                                <form method="post" action="{{route('superadmin.pay.settings')}}" id="paymentSettingsForm">
                                    @csrf
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>
                                                    <input class="form-check-input" 
                                                           type="checkbox" 
                                                           name="enable_offline_payment" 
                                                           value="1" 
                                                           {{ $settings->enable_offline_payment ? 'checked' : '' }}>
                                                    Enable Offline Payment
                                                </label>
                                            </div>

                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="offline_payment_details">Offline payment details:</label>
                                                <i class="fa fa-info-circle text-info hover-q no-print" aria-hidden="true" data-toggle="popover" data-placement="auto bottom" data-content="Offline payment instructions, like bank account details" data-html="true" data-trigger="hover"></i>
                                                <textarea class="form-control" placeholder="Offline payment details" rows="3" name="offline_payment_details" id="offline_payment_details">{{$settings->offline_payment_details}}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                     <!-- Flutterwave Section -->
                                    <div class="row mt-2">
                                        <h4>Flutterwave:</h4>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="FLUTTERWAVE_PUBLIC_KEY">Public Key:</label>
                                                <input class="form-control" name="flutterwave_public_key"
                                                value="{{$settings->flutterwave_public_key}}"
                                                type="text" id="FLUTTERWAVE_PUBLIC_KEY">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="FLUTTERWAVE_SECRET_KEY">Secret Key:</label>
                                                <input class="form-control" 
                                                value="{{$settings->flutterwave_secret_key}}"
                                                name="flutterwave_secret_key" type="text" id="FLUTTERWAVE_SECRET_KEY">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="FLUTTERWAVE_ENCRYPTION_KEY">Encryption Key:</label>
                                                <input class="form-control" 
                                                value="{{$settings->flutterwave_encryption_key}}"
                                                name="flutterwave_encryption_key" type="text" id="FLUTTERWAVE_ENCRYPTION_KEY">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Stripe Section -->
                                    <div class="row">
                                        <h4>Stripe:</h4>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="STRIPE_PUB_KEY">Stripe Pub Key:</label>
                                                <input class="form-control" placeholder="Stripe Pub Key" name="stripe_pub_key" type="text" id="STRIPE_PUB_KEY">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="STRIPE_SECRET_KEY">Stripe Secret Key:</label>
                                                <input class="form-control" placeholder="Stripe Secret Key" name="stripe_secret_key" type="text" id="STRIPE_SECRET_KEY">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Paypal Section -->
                                    <div class="row mt-2">
                                        <h4>Paypal:</h4>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="PAYPAL_MODE">Mode:</label>
                                                <select class="form-control" id="PAYPAL_MODE" name="paypal_mode">
                                                    <option value="">Please Select</option>
                                                    <option value="live">Live</option>
                                                    <option value="sandbox" selected>Sandbox</option>
                                                </select>
                                                <b><span class="text-danger">IMPORTANT</span> Set mode to Live for actual payment; sandbox is only for testing.</b>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="PAYPAL_CLIENT_ID">Paypal Client ID:</label>
                                                <input class="form-control" placeholder="Paypal client id" name="paypal_client_id" type="text" id="PAYPAL_CLIENT_ID">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="PAYPAL_APP_SECRET">Paypal App Secret:</label>
                                                <input class="form-control" placeholder="Paypal app secret" name="paypal_app_secret" type="text" id="PAYPAL_APP_SECRET">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Pesapal Section -->
                                    <div class="row mt-2">
                                        <h4>Pesapal: <small>(For KES currency)</small></h4>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="pesapal_consumer_key">Consumer Key:</label>
                                                <input class="form-control" name="pesapal_consumer_key" type="text" id="pesapal_consumer_key">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="pesapal_consumer_secret">Consumer Secret:</label>
                                                <input class="form-control" name="pesapal_consumer_secret" type="text" id="pesapal_consumer_secret">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="PESAPAL_LIVE">Is Live?</label>
                                                <select class="form-control" id="PESAPAL_LIVE" name="pesapal_live">
                                                    <option value="0" selected>False</option>
                                                    <option value="1">True</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Paystack Section -->
                                    <div class="row mt-2">
                                        <h4>Paystack: <small>(For NGN Nigeria, GHS Ghana)</small></h4>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="paystack_public_key">Public Key:</label>
                                                <input class="form-control" name="paystack_public_key" type="text" id="paystack_public_key">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="paystack_secret_key">Secret Key:</label>
                                                <input class="form-control" name="paystack_secret_key" type="text" id="paystack_secret_key">
                                            </div>
                                        </div>
                                    </div>
                                    
                                   
                                    
                                    <!-- Submit Button -->
                                    <div class="row mt-3">
                                        <div class="col-12 text-center">
                                            <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
   
                </div>
            </div>
        </div>
    </div>

@endsection

@section('styles')
    <!-- Add any page-specific CSS here -->
    <style>
        .bg-light {
            background-color: #fff !important;
        }
        /*.navbar-nav .show>.nav-link, .navbar-nav .nav-link.active {*/
        /*    color: blue;*/
        /*}*/
        .nav-item-sa {
            padding: 10px;
            font-size: 16px;
            line-height: 20px;
        }
        .nav-pills .nav-link {
            font-size: larger;
            font-weight: 600;
        }
        .nav-link {
            color: #31374a;
        }
    </style>
@endsection

@section('scripts')
    <!-- Add any page-specific JavaScript here -->
@endsection
