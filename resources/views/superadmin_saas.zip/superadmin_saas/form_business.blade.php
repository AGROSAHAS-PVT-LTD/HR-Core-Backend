@php
    use App\Models\Settings;
    $title = $business ? 'Edit Business | Super Admin' : 'Create Business | Super Admin';
    $settings = Settings::first();
@endphp

@extends('layout')

@section('title', $title)

@section('main-content')
   @include('nav')
    <div class="row mb-3 mt-5">
        <div class="col">
            <div class="float-start">
                <h4 class="mt-2">{{$title}}</h4>
            </div>
        </div>
    </div>
    <form action="{{ route($business ? 'superadmin.businesses.update' : 'superadmin.businesses.store', $business ? $business->id : '') }}" 
    method="post" enctype="multipart/form-data">
        @csrf
        @if ($business)
            @method('PUT')
        @endif
        <div class="card shadow">
            <div class="card-body">
                <div class="card-primary">
                    <div class="card-body">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <!-- Business Information -->
                        <h4 class="mt-2">Business Information</h4>
                        <div class="form-group row mt-4">
                            <div class="form-group col-md-4 mb-3">
                                <label for="name" class="control-label">Business Name *</label>
                                <input id="name" name="name" class="form-control" value="{{ old('name', $business->name ?? '') }}" required/>
                                <span class="text-danger">{{ $errors->first('name', ':message') }}</span>
                            </div>

                            <div class="form-group col-md-4 mb-3">
                                <label for="email" class="control-label">Business Email *</label>
                                <input id="email" name="email" type="email" class="form-control" value="{{ old('email', $business->email ?? '') }}" required/>
                                <span class="text-danger">{{ $errors->first('email', ':message') }}</span>
                            </div>

                            <div class="form-group col-md-4 mb-3">
                                <label for="contact" class="control-label">Business Contact</label>
                                <input id="contact" name="contact" class="form-control" value="{{ old('contact', $business->contact ?? '') }}"/>
                                <span class="text-danger">{{ $errors->first('contact', ':message') }}</span>
                            </div>
                        </div>

                        <!-- Business Address and Info -->
                        <div class="form-group row">
                            <div class="form-group col-md-4 mb-3">
                                <label for="country" class="control-label">Country *</label>
                                <input id="country" name="country" class="form-control" value="{{ old('country', $business->country ?? '') }}" required/>
                                <span class="text-danger">{{ $errors->first('country', ':message') }}</span>
                            </div>

                            <div class="form-group col-md-4 mb-3">
                                <label for="city" class="control-label">City *</label>
                                <input id="city" name="city" class="form-control" value="{{ old('city', $business->city ?? '') }}" required/>
                                <span class="text-danger">{{ $errors->first('city', ':message') }}</span>
                            </div>

                            <div class="form-group col-md-4 mb-3">
                                <label for="website" class="control-label">Website</label>
                                <input id="website" name="website" type="url" class="form-control" value="{{ old('website', $business->website ?? '') }}"/>
                                <span class="text-danger">{{ $errors->first('website', ':message') }}</span>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="form-group col-md-4 mb-3">
                                <label for="start_date" class="control-label">Start Date</label>
                                <input id="start_date" name="start_date" type="date" class="form-control" value="{{ old('start_date', $business->start_date ?? '') }}"/>
                                <span class="text-danger">{{ $errors->first('start_date', ':message') }}</span>
                            </div>

                            <div class="form-group col-md-4 mb-3">
                                <label for="address" class="control-label">Address</label>
                                <input id="address" name="address" class="form-control" value="{{ old('address', $business->address ?? '') }}"/>
                                <span class="text-danger">{{ $errors->first('address', ':message') }}</span>
                            </div>

                            <div class="form-group col-md-4 mb-3">
                                <label for="logo" class="control-label">Business Logo</label>
                                <input id="logo" name="logo" type="file" class="form-control" />
                                <span class="text-danger">{{ $errors->first('logo', ':message') }}</span>
                            </div>
                            
                        </div>

                        <div class="form-group row">
                            <div class="form-group col-md-12 mb-3">
                                <label for="description" class="control-label">Business Description</label>
                                <textarea id="description" name="description" class="form-control">{{ old('description', $business->description ?? '') }}</textarea>
                                <span class="text-danger">{{ $errors->first('description', ':message') }}</span>
                            </div>
                        </div>
                        
                        <!-- Subscription Information -->
                        <h4 class="mt-2">Subscription Information</h4>
                        <div class="form-group row mt-4">
                            <div class="form-group col-md-4 mb-3">
                                <label for="package" class="control-label">Subscription Package *</label>
                                <select id="package" name="package" class="form-control" required>
                                    <option value="">Select a Package</option>
                                    @foreach ($packages as $package)
                                        <option value="{{ $package->id }}" {{ old('package', $business->package_id ?? '') == $package->id ? 'selected' : '' }}>
                                            {{ $package->name }} - {{ $package->price }}  <!-- Adjust according to your package fields -->
                                        </option>
                                    @endforeach
                                </select>
                                <span class="text-danger">{{ $errors->first('package', ':message') }}</span>
                            </div>

                            <div class="form-group col-md-4 mb-3">
                                <label for="paid_via" class="control-label">Paid Via *</label>
                                <select id="paid_via" name="paid_via" class="form-control" required>
                                    <option value="">Select Payment Method</option>
                                    @foreach ($paymentMethods as $method)
                                        <option value="{{ $method }}" {{ old('paid_via', $business->paid_via ?? '') == $method ? 'selected' : '' }}>{{ $method }}</option>
                                    @endforeach
                                </select>
                                <span class="text-danger">{{ $errors->first('paid_via', ':message') }}</span>
                            </div>

                            <div class="form-group col-md-4 mb-3">
                                <label for="transaction_id" class="control-label">Transaction ID *</label>
                                <input id="transaction_id" name="transaction_id" class="form-control" value="{{ old('transaction_id', $business->transaction_id ?? '') }}" required/>
                                <span class="text-danger">{{ $errors->first('transaction_id', ':message') }}</span>
                            </div>
                        </div>
                        


                        <!-- Owner Information -->
                        <h4 class="mt-2">Owner Information</h4>
                        <div class="form-group row mt-4">
                            <div class="form-group col-md-4 mb-3">
                                <label for="first_name" class="control-label">Owner First Name *</label>
                                <input id="first_name" name="first_name" class="form-control" value="{{ old('first_name', $user->first_name ?? '') }}" required/>
                                <span class="text-danger">{{ $errors->first('first_name', ':message') }}</span>
                            </div>

                            <div class="form-group col-md-4 mb-3">
                                <label for="last_name" class="control-label">Owner Last Name *</label>
                                <input id="last_name" name="last_name" class="form-control" value="{{ old('last_name', $user->last_name ?? '') }}" required/>
                                <span class="text-danger">{{ $errors->first('last_name', ':message') }}</span>
                            </div>

                            <div class="form-group col-md-4 mb-3">
                                <label for="user_name" class="control-label">Owner Username *</label>
                                <input id="user_name" name="user_name" class="form-control" value="{{ old('user_name', $user->user_name ?? '') }}" required/>
                                <span class="text-danger">{{ $errors->first('user_name', ':message') }}</span>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="form-group col-md-4 mb-3">
                                <label for="email" class="control-label">Owner Email *</label>
                                <input id="email" name="email" type="email" class="form-control" value="{{ old('email', $user->email ?? '') }}" required/>
                                <span class="text-danger">{{ $errors->first('email', ':message') }}</span>
                            </div>

                            <div class="form-group col-md-4 mb-3">
                                <label for="phone_number" class="control-label">Owner Phone Number *</label>
                                <input id="phone_number" name="phone_number" class="form-control" value="{{ old('phone_number', $user->phone_number ?? '') }}" required/>
                                <span class="text-danger">{{ $errors->first('phone_number', ':message') }}</span>
                            </div>

                        </div>
                        <div class="form-group row">
                            <div class="form-group col-md-4 mb-3">
                                <label for="password" class="control-label">Password *</label>
                                <input id="password" name="password" type="password" class="form-control" required/>
                                <span class="text-danger">{{ $errors->first('password', ':message') }}</span>
                            </div>

                            <div class="form-group col-md-4 mb-3">
                                <label for="password_confirmation" class="control-label">Confirm Password *</label>
                                <input id="password_confirmation" name="password_confirmation" type="password" class="form-control" required/>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group row mt-4">
                    <div class="form-group col-md-4 mb-3">
                        <button class="btn btn-success float-start" type="submit">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>



@endsection
@section('styles')
    <style>
        .bg-light {
            background-color: #fff !important;
        }
        .navbar-nav .show>.nav-link, .navbar-nav .nav-link.active {
            color: blue;
        }
        .nav-item-sa {
            padding: 10px;
            font-size: 16px;
        }
    </style>
@endsection