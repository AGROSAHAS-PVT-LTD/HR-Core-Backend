@php
    $title = 'Super Admin';
@endphp

@extends('layouts/layoutMaster')

@section('title', 'Super Admin Dashboard')

@section('content')
   @include('nav')
    
    <div class="container-fluid mt-4">
        <!-- Date Filter Controls -->
        <div class="row">
            <div class="col-12">
                <div class="btn-group float-end" role="group" data-toggle="buttons">
                    <label class="btn btn-info">
                        <input type="radio" name="date-filter" value="today" checked> Today
                    </label>
                    <label class="btn btn-info">
                        <input type="radio" name="date-filter" value="this-week"> This Week
                    </label>
                    <label class="btn btn-info">
                        <input type="radio" name="date-filter" value="this-month"> This Month
                    </label>
                    <label class="btn btn-info">
                        <input type="radio" name="date-filter" value="this-year"> This Year
                    </label>
                </div>
            </div>
        </div>

        </br>

        <!-- Cards displaying data -->
        <div class="row">
            <!-- First Card: New Subscriptions -->
            <div class="col-lg-4 col-6">
                <div class="card mb-4 shadow-sm hover-shadow-md rounded-xl border border-light">
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-4">
                            <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-info text-white" style="width: 3rem; height: 3rem;">
                               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-refresh">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <path d="M20 11a8.1 8.1 0 0 0 -15.5 -2m-.5 -4v4h4"></path>
                                    <path d="M4 13a8.1 8.1 0 0 0 15.5 2m.5 4v-4h-4"></path>
                                </svg>
                            </div>
                            <div class="flex-1 min-w-0">
                                <h3><span class="new_subscriptions">{{ number_format($newSubscriptions, 0) }}</span></h3>
                                <p class="text-sm font-medium text-muted truncate">New Subscriptions</p>
                                <a href="{{ route('superadmin.subscriptions') }}" class="small-box-footer">More Information <i class="fa fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Second Card: New Business Registrations -->
            <div class="col-lg-4 col-6">
                <div class="card mb-4 shadow-sm hover-shadow-md rounded-xl border border-light">
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-4">
                            <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-info text-white" style="width: 3rem; height: 3rem;">
                               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-user-plus">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0"></path>
                                    <path d="M16 19h6"></path>
                                    <path d="M19 16v6"></path>
                                    <path d="M6 21v-2a4 4 0 0 1 4 -4h4"></path>
                                </svg>
                            </div>
                            <div class="flex-1 min-w-0">
                                <h3><span class="new_registrations">{{ number_format($newBusinessRegistrations, 0) }}</span></h3>
                                <p class="text-sm font-medium text-muted truncate">New Business Registrations</p>
                                <a href="{{ route('superadmin.businesses') }}" class="small-box-footer">More Information <i class="fa fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Third Card: Not Subscribed -->
            <div class="col-lg-4 col-6">
                <div class="card mb-4 shadow-sm hover-shadow-md rounded-xl border border-light">
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-4">
                            <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-danger text-white" style="width: 3rem; height: 3rem;">
                               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-chart-pie">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <path d="M10 3.2a9 9 0 1 0 10.8 10.8a1 1 0 0 0 -1 -1h-6.8a2 2 0 0 1 -2 -2v-7a.9 .9 0 0 0 -1 -.8"></path>
                                    <path d="M15 3.5a9 9 0 0 1 5.5 5.5h-4.5a1 1 0 0 1 -1 -1v-4.5"></path>
                                </svg>
                            </div>
                            <div class="flex-1 min-w-0">
                                <h3> <span class="not_subscribed">{{ number_format($notSubscribed, 0) }}</span> </h3>
                                <p class="text-sm font-medium text-muted truncate">Not Subscribed</p>
                                <a href="{{ route('superadmin.businesses') }}" class="small-box-footer">More Information <i class="fa fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Chart for monthly sales (or any other info you want to display) -->
        <div class="row">
            <div class="col-12">
                <div class="transition-all mb-4 bg-white shadow-sm rounded-xl ring-1 ring-gray-200 hover:shadow-md hover:translate-y-1">
                    <div class="p-4 p-sm-5">
                        <div class="d-flex align-items-center gap-3">
                            <h4 class="flex-1 text-base font-medium text-gray-900 text-truncate">
                                Sale - Monthly for 12 Months
                            </h4>
                        </div>
                        <!-- Chart for monthly sales -->
                        <div class="mt-4">
                            <canvas id="monthlySubscriptionChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('styles')
    <!-- Add any page-specific CSS here -->
   <style>
        .bg-light {
        background-color: #fff !important;
    }
    .navbar-nav .show>.nav-link, .navbar-nav .nav-link.active {
        color: blue;
    }
    .nav-item-sa{
            /*height: 50px;*/
            padding: 10px;
            font-size: 16px;
    }
       
   </style>
@endsection

@section('scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        $(document).ready(function() {
            // Function to calculate the date range for "Today"
            function getTodayRange() {
                let today = new Date();
                let startDate = new Date(today.setHours(0, 0, 0, 0));
                let endDate = new Date(today.setHours(23, 59, 59, 999));
                return { start: startDate, end: endDate };
    }
        
            // Function to calculate the date range for "This Week"
            function getThisWeekRange() {
                let today = new Date();
                let startDate = new Date(today.setDate(today.getDate() - today.getDay())); // Set to the beginning of the week
                startDate.setHours(0, 0, 0, 0);
                let endDate = new Date(startDate);
                endDate.setDate(endDate.getDate() + 6); // Set to the end of the week
                endDate.setHours(23, 59, 59, 999);
                return { start: startDate, end: endDate };
    }
        
            // Function to calculate the date range for "This Month"
            function getThisMonthRange() {
                let today = new Date();
                let startDate = new Date(today.getFullYear(), today.getMonth(), 1); // First day of the month
                startDate.setHours(0, 0, 0, 0);
                let endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0); // Last day of the month
                endDate.setHours(23, 59, 59, 999);
                return { start: startDate, end: endDate };
    }
        
            // Function to calculate the date range for "This Year"
            function getThisYearRange() {
                let today = new Date();
                let startDate = new Date(today.getFullYear(), 0, 1); // First day of the year
                startDate.setHours(0, 0, 0, 0);
                let endDate = new Date(today.getFullYear(), 11, 31); // Last day of the year
                endDate.setHours(23, 59, 59, 999);
                return { start: startDate, end: endDate };
    }
        
            // Handle the initial load for "Today"
            // let todayRange = getTodayRange();
            // fetchFilteredData(todayRange.start, todayRange.end);
        
            // When a user selects a new date filter
            $('input[name="date-filter"]').on('change', function() {
                let filter = $(this).val();
                let range;
                
                 // Deselect all buttons
                $('input[name="date-filter"]').prop('checked', false);

                // Mark the selected filter as checked
                $(this).prop('checked', true);
                switch (filter) {
                    case 'today':
                        range = getTodayRange();
                        break;
                    case 'this-week':
                        range = getThisWeekRange();
                        break;
                    case 'this-month':
                        range = getThisMonthRange();
                        break;
                    case 'this-year':
                        range = getThisYearRange();
                        break;
                }
                fetchFilteredData(range.start, range.end);
             });
        
            // Function to fetch data based on the selected date range
            function fetchFilteredData(startDate, endDate) {
                $.ajax({
                    url: '/public/superadmin/dashboard/',  // The endpoint to handle the request
                    type: 'GET',
                    data: {
                        start_date: startDate.toISOString(),  // Convert to ISO string
                        end_date: endDate.toISOString()       // Convert to ISO string
                    },
                    success: function(response) {
                        // Update the data on the page with the new values
                        $('.new_subscriptions').text(response.new_subscriptions);
                        $('.new_registrations').text(response.new_registrations);
                        $('.not_subscribed').text(response.not_subscribed);
                    },
                    error: function(error) {
                        console.log('Error:', error);
                    }
                });
    }
            
        

    
        });
        
    </script>
    
    <script>
        // Make AJAX call to get monthly subscription data
        $.ajax({
            url: '/public/superadmin/monthly-subscription-data',
            type: 'GET',
            success: function(response) {
                
                const chartData = {
                    labels: response.months,  // Use months from response
                    datasets: [{
                        label: 'Total Subscriptions (UGX)',
                        data: response.amounts,  // Use amounts from response
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',  // Light blue for bars
                        borderColor: 'rgba(54, 162, 235, 1)',      // Blue for bar border
                        borderWidth: 1,
                        fill: true, // Keep this true to fill the bars (can be set to false if you don't want filled bars)
                    }]
                };
    
                // Render the chart using Chart.js (Bar chart type)
                const ctx = document.getElementById('monthlySubscriptionChart').getContext('2d');
                new Chart(ctx, {
                    type: 'bar',  // Change type to 'bar' for bar chart
                    data: chartData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            x: {
                                beginAtZero: true
                            },
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    stepSize: 10000,  // Adjust as needed for better readability
                                    callback: function(value) {
                                        return value;  // Optional: format Y-axis as currency
                                    }
                                }
                            }
                        },
                        plugins: {
                            legend: {
                                display: true,
                                position: 'top',
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(tooltipItem) {
                                        return tooltipItem.raw;  // Format tooltips as currency
                                    }
                                }
                            }
                        },
                    }
                });
            },
            error: function(error) {
                console.log('Error fetching subscription data:', error);
            }
        });
    </script>
@endsection

