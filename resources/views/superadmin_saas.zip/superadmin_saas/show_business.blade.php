@php
    use App\Models\Settings;
    $title = $business->name;
    $settings = Settings::first();
@endphp

@extends('layout')

@section('title', $title)

@section('main-content')
    @include('nav')
    <div class="row mb-3 mt-5">
        <div class="col">
            <div class="float-start">
                <h4 class="mt-2">{{ $title }}</h4>
            </div>
        </div>
    </div>

    <div class="container-fluid mt-4">
        <!-- Reminder Section -->
        @if(!$business->is_active || !$currentSubscription || !$currentSubscription->isActive())
            <div class="alert alert-primary text-white">
                <h5><i class="fa fa-exclamation-triangle"></i> Important Reminder</h5>
                <ul>
                    @if(!$business->is_active)
                        <li>
                            The business <strong>{{ $business->name }}</strong> is currently marked as <strong>Inactive</strong>. 
                            Please review the status or activate it to ensure full functionality.
                        </li>
                    @endif
                    @if(!$currentSubscription || !$currentSubscription->isActive())
                        <li>
                            The business does not have an active subscription or the current subscription has expired. 
                            Encourage the owner to renew or purchase a subscription to avoid service interruptions.
                        </li>
                    @endif
                </ul>
            </div>
        @endif
        <!-- Business Information Section -->
        <div class="business-info row my-4 px-3">
            <!-- Business Details -->
            <div class="business-section me-3 card col-md-3 p-3">
                <h4><i class="fa fa-briefcase"></i> Business Name</h4></br>
                <span>{{ $business->name }}</span>
                 <span><strong>Email:</strong> {{ $business->email }}</span>
                  <span><strong>Contact:</strong> {{ $business->contact }}</span>
                <span><strong>Status:</strong> {{ $business->is_active ? 'Active' : 'Inactive' }}</span>
                <span><strong>Created At:</strong> {{ $business->created_at->format('Y-m-d H:i:s') }}</span>
            </div>

           <!-- Time Zone and Status -->
            <div class="timezone-section me-3 card col-md-3 p-3">
                <h4><i class="fa fa-box"></i> Subscription</h4><br/>
            
                @if($currentSubscription)
                    <span><strong>Current Subscription:</strong> {{ $currentSubscription->package->name ?? 'N/A' }}</span>
                    <span><strong>Subscription Price:</strong> UGX. {{ $currentSubscription->formatted_package_price }}</span>
                    <span><strong>Subscription Type:</strong> {{ $currentSubscription->isInTrialPeriod() ? 'Trial' : 'Paid' }}</span>
                    <span><strong>Subscription Status:</strong> {{ $currentSubscription->isActive() ? 'Active' : 'Expired or Inactive' }}</span>
                    <span><strong>Remaining Days:</strong> {{ $currentSubscription->remaining_days }} days remaining</span>
                @else
                    <span>No active subscription available.</span>
                @endif
            </div>


            <!-- Owner Details -->
            <div class="owner-section me-3 card col-md-3 p-3">
                <h4><i class="fa fa-user"></i> Owner</h4></br>
                <span> {{ $business->owner->first_name ?? ''}} {{ $business->owner->last_name ?? '' }}</span>
                <span><i class="fa fa-envelope"></i> {{ $business->owner->email ?? 'N/A' }}</span>
                <span><strong>Mobile:</strong> {{ $business->owner->phone_number ?? 'N/A' }}</span>
                <span><strong>Address:</strong> {{ $business->owner->address ?? 'N/A' }}</span>
            </div>
        </div>

        <!-- Package Subscription Details Section -->
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-box"></i> Package Subscription Details
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="datatable" class="table table-striped">
                        <thead>
                            <tr>
                                <th>Package Name</th>
                                <th>Start Date</th>
                                <th>Trial End Date</th>
                                <th>End Date</th>
                                <th>Paid Via</th>
                                <th>Payment Transaction ID</th>
                                <th>Created At</th>
                                <th>Status</th>

                                <!--<th>Created By</th>-->
                            </tr>
                        </thead>
                        <tbody>
                           




                            @foreach ($business->subscriptions as $subscription)
                                <tr>
                                    <td>{{ $subscription->package->name }}</td>
                                     <td>{{ $subscription->start_date }}</td>
                                   <td>{{ $subscription->trial_end_date }}</td>
                                    <td>{{ $subscription->end_date }}</td>
                                    <td>{{ $subscription->paid_via  ?? 'N/A'}}</td>
                                    <td>{{ $subscription->payment_transaction_id ?? 'N/A' }}</td>
                                   <td>{{ $subscription->created_at?->format('Y-m-d H:i:s') ?? 'N/A' }}</td>
                                    <td>
                                        <span class="badge 
                                            {{ $subscription->status == 'approved' ? 'bg-success' : 
                                               ($subscription->status == 'waiting' ? 'bg-warning' : 'bg-danger') }}">
                                            {{ ucfirst($subscription->status) }}
                                        </span>
                                    </td>
                                    <!--<td>{{ $subscription->created_by }}</td>-->
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- All Users Section -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-users"></i> All Users
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="datatable" class="table table-striped">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Name</th>
                                <th>Role</th>
                                <th>Email</th>
                                 <th>Status</th>
                                  <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($business->users as $user)
                                <tr>
                                    <td> {{ Str::afterLast($user->user_name, '_') }}</td>
                                    <td>{{ $user->first_name ?? '' }} {{ $user->last_name ?? ''}}</td>
                                    <td>{{ $user->getPrimaryRoleName() }}</td>
                                    <td>{{ $user->email }}</td>
                                    <td>
                                    <!-- Form-switch for Status Toggle -->
                                    <div class="form-check form-switch">
                                        <input type="checkbox" class="form-check-input" id="statusSwitch{{ $user->id }}"
                                           onchange="toggleStatus({{ $user->id }}, this.checked)" 
                                           {{ $user->status == 'active' ? 'checked' : '' }}>
                                            <label class="form-check-label" for="statusSwitch{{ $user->id }}">
                                                {{ ucfirst($user->status) }}
                                            </label>
                                        </div>
                                    </td>
                                    <!--<td>-->
                                    <!--    <span class="badge {{ $user->status == 'active' ? 'bg-success' : 'bg-danger' }}">-->
                                    <!--        {{ ucfirst($user->status) }}-->
                                    <!--    </span>-->
                                    <!--</td>-->
                                    <td>
                                        <div class="d-flex">
                                            <!-- Reset Password Button -->
                                            <button class="btn btn-outline-primary btn-sm me-2" onclick="openPasswordResetModal({{ $user->id }})">
                                                Reset Password
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="text-center">No data available in table</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Password Reset Modal -->
<form id="passwordResetForm" method="POST">
    @csrf
    <div class="modal fade" id="passwordResetModal" tabindex="-1" aria-labelledby="passwordResetModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="passwordResetModalLabel">Reset Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Password field -->
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-control" required>

                    <!-- Confirm Password field -->
                    <label for="confirm_password" class="mt-3">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Reset Password</button>
                </div>
            </div>
        </div>
    </div>
</form>

    
@endsection


@section('styles')
    <style>
        .bg-light {
            background-color: #fff !important;
        }
        .navbar-nav .show>.nav-link, .navbar-nav .nav-link.active {
            color: blue;
        }
        .nav-item-sa {
            padding: 10px;
            font-size: 16px;
        }
    </style>
@endsection



@section('scripts')
@section('scripts')
@section('scripts')
<script>
    function toggleStatus(userId, isActive) {
        const newStatus = isActive ? 'active' : 'inactive';
        fetch(`/public/superadmin/users/toggle-status/${userId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({ status: newStatus })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById(`statusSwitch${userId}`).nextElementSibling.innerHTML = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
            } else {
                alert("Failed to update status.");
            }
        })
        .catch(error => console.error('Error:', error));
    }

    function openPasswordResetModal(userId) {
        document.getElementById('passwordResetForm').action = `/public/superadmin/users/reset-password/${userId}`;
        new bootstrap.Modal(document.getElementById('passwordResetModal')).show();
    }
</script>
@endsection

@endsection

@endsection